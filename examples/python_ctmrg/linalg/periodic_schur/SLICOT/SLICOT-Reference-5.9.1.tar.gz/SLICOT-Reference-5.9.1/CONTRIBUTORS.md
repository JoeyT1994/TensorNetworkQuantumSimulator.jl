Contributors
============

Current Maintainers
-------------------
After the release of SLICOT 5.9.0 the maintainance of SLICOT was handed over to

* Martin Köhler (@grisuthedragon), MPI Magdeburg
* Jens Saak (@drittelhacker), MPI Magdeburg

Contributors since Version 5.9.0
--------------------------------


Contributors until Version 5.9.0
--------------------------------

Maintainers:

* Vasile Sima
* Andreas Varga

The development of the SLICOT Library (Subroutine Library In COntrol Theory)
owe much to many people. We especially thank all those who have contributed
routines to the Library, including

 * E. Barth,
 * Th. Beelen
 * P. Benner
 * C. Benson
 * R. Byers
 * R. Dekeyser
 * F. Delebecque
 * M. Denham
 * F. Dumortier
 * A. Emami-Naeini
 * Da-Wei Gu
 * A. Geurts
 * S. Hammarling
 * G. van den Hurk
 * B. Kågström
 * C. Kliman
 * M. Konstantinov
 * D. Kressner
 * A. Laub
 * A. Markovsky
 * C. Paige
 * Th. Penzl
 * P. Petkov
 * E. S. Quintana-Orti
 * G. Quintana-Orti
 * P.A. Regalia
 * A. Riedel
 * R. Schneider
 * V. Sima
 * D.M. Sima
 * S. Steer
 * F. Svaricek
 * M. Vanbegin
 * P. Van Dooren
 * S. Van Huffel
 * A. Varga
 * M. Verhaegen
 * M. Voigt
 * L. Westin
 * H. Willemsen
 * T. Williams
 * H. Xu.

The precursor of SLICOT was the version derived in the early eighties by the
integration of SLICE and SYCOT, as a result of a cooperation between the
Numerical Algorithms Group (NAG) from Oxford (UK) and Working Group on Software
(WGS) - a Benelux cooperation.  This SLICOT version, commercialized by NAG, had
two releases, in 1991 and 1993.  Later, WGS, NAG, and German Aerospace Center
(DLR) in Oberpfaffenhofen, Germany, decided to make SLICOT freely available,
and the first public release (Release 3) of SLICOT in 1997 was based entirely
on the freeware BLAS and LAPACK subroutines.

Financial Support
-----------------

SLICOT was developed and maintained by NICONET (Numerics In COntrol NETwork),
then later by Niconet e.V.  The initial work for library conversion to a public
version and further extension was supported by the European Community
BRITE-EURAM III Thematic Networks Programme NICONET (project BRRT–CT97-5040,
1997-2002).  Further developments were mainly supported by several grants of
the German Science Foundation (2004-2009), and by The MathWorks (starting with
2008).

All this support is highly acknowledged.
